twitter-login-node
==================

Twitter Login using Node and MySQL

Download project and run <code>npm install</code>.

Type <code>node app.js</code> to run the project.

